// frontend/src/DebugAuthContext.js
import React, { useContext } from 'react';
import { AuthContext } from './AuthContext';

const DebugAuthContext = () => {
  const context = useContext(AuthContext);
  console.log('DebugAuthContext:', context);
  return null;
};

export default DebugAuthContext;
