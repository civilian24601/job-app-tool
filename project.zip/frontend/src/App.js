import React, { useState, useContext } from 'react';
import { AppBar, Toolbar, Button, Box } from '@mui/material';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import Dashboard from './Dashboard';
import ThemeToggle, { ThemeToggleButton } from './ThemeToggle';
import AuthModal from './components/AuthModal';
import UserProfile from './components/UserProfile';
import { AuthContext } from './AuthContext';
import DebugAuthContext from './DebugAuthContext';
import { ToastContainer } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';

function App() {
  const [authOpen, setAuthOpen] = useState(false);
  const [isLogin, setIsLogin] = useState(true);
  const { user, logout } = useContext(AuthContext);

  return (
    <ThemeToggle>
      <Router>
        <AppBar position="static">
          <Toolbar>
            <Box sx={{ flexGrow: 1 }}>
              <ThemeToggleButton />
            </Box>
            {!user ? (
              <>
                <Button color="inherit" onClick={() => { setAuthOpen(true); setIsLogin(true); }}>Login</Button>
                <Button color="inherit" onClick={() => { setAuthOpen(true); setIsLogin(false); }}>Register</Button>
              </>
            ) : (
              <UserProfile onLogout={logout} />
            )}
          </Toolbar>
        </AppBar>
        <div className="App">
          <AuthModal open={authOpen} onClose={() => setAuthOpen(false)} isLogin={isLogin} />
          <Routes>
            <Route path="/" element={<Dashboard />} />
          </Routes>
          <DebugAuthContext />
          <ToastContainer />
        </div>
      </Router>
    </ThemeToggle>
  );
}

export default App;
