import React, { useState } from 'react';
import axios from 'axios';

const FileUpload = () => {
  const [file, setFile] = useState(null);
  const [message, setMessage] = useState('');
  const [parsedData, setParsedData] = useState(null);

  const handleFileChange = (e) => {
    setFile(e.target.files[0]);
  };

  const handleFileUpload = async (e) => {
    e.preventDefault();
    if (!file) {
      setMessage('Please select a file to upload.');
      return;
    }
    const formData = new FormData();
    formData.append('resume', file);

    try {
      const response = await axios.post('http://localhost:5001/api/uploads/upload', formData, {
        headers: {
          'Content-Type': 'multipart/form-data',
        },
      });
      setMessage(response.data.message);
      setParsedData(response.data.parsedData);
    } catch (error) {
      setMessage('Failed to upload file');
      console.error('Error uploading file:', error);
    }
  };

  return (
    <div>
      <h2>Upload Resume</h2>
      <form onSubmit={handleFileUpload}>
        <input type="file" onChange={handleFileChange} />
        <button type="submit">Upload</button>
      </form>
      {message && <p>{message}</p>}
      {parsedData && (
        <div>
          <h3>Parsed Data</h3>
          <p>Name: {parsedData.name}</p>
          <p>Email: {parsedData.email}</p>
        </div>
      )}
    </div>
  );
};

export default FileUpload;
