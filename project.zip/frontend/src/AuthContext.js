import React, { createContext, useState, useEffect } from 'react';
import axios from 'axios';

export const AuthContext = createContext();

export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(null);
  const [token, setToken] = useState(localStorage.getItem('token') || '');

  useEffect(() => {
    const fetchUser = async () => {
      if (token) {
        try {
          const response = await axios.get('http://localhost:5001/api/users/profile', {
            headers: { 'auth-token': token },
          });
          setUser(response.data);
        } catch (error) {
          console.error('Error fetching user:', error);
        }
      }
    };

    fetchUser();
  }, [token]);

  const register = async (name, email, password) => {
    try {
      const response = await axios.post('http://localhost:5001/api/users/register', { name, email, password });
      const { token, user } = response.data;
      setToken(token);
      localStorage.setItem('token', token);
      setUser(user);
    } catch (error) {
      console.error('Error registering user:', error);
      throw error;
    }
  };

  const login = async (email, password) => {
    try {
      const response = await axios.post('http://localhost:5001/api/users/login', { email, password });
      const { token, user } = response.data;
      setToken(token);
      localStorage.setItem('token', token);
      setUser(user);
    } catch (error) {
      console.error('Error logging in:', error);
      throw error;
    }
  };

  const logout = () => {
    setToken('');
    setUser(null);
    localStorage.removeItem('token');
  };

  return (
    <AuthContext.Provider value={{ user, token, register, login, logout, setUser }}>
      {children}
    </AuthContext.Provider>
  );
};

export default AuthProvider;
