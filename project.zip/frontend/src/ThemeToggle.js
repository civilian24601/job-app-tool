// frontend/src/ThemeToggle.js
import React, { useState, useMemo, createContext, useContext } from 'react';
import { createTheme, ThemeProvider, useTheme } from '@mui/material/styles';
import { CssBaseline, Switch, Paper } from '@mui/material';
import { Brightness4, Brightness7 } from '@mui/icons-material';

const ColorModeContext = createContext({ toggleColorMode: () => {} });

const ThemeToggle = ({ children }) => {
  const [mode, setMode] = useState('light');
  const colorMode = useMemo(
    () => ({
      toggleColorMode: () => {
        setMode(prevMode => (prevMode === 'light' ? 'dark' : 'light'));
      },
    }),
    [],
  );

  const theme = useMemo(
    () => createTheme({
      palette: {
        mode,
        ...(mode === 'dark' && {
          background: {
            default: '#1e1e1e', // Darker background color
          },
          text: {
            primary: '#ffffff', // White text color
          }
        }),
        ...(mode === 'light' && {
          background: {
            default: '#f4f6f8', // Lighter background color
          },
          text: {
            primary: '#1e1e1e', // Dark text color
          }
        }),
      },
    }),
    [mode],
  );

  return (
    <ColorModeContext.Provider value={colorMode}>
      <ThemeProvider theme={theme}>
        <CssBaseline />
        {children}
      </ThemeProvider>
    </ColorModeContext.Provider>
  );
};

export const useColorMode = () => useContext(ColorModeContext);

export const ThemeToggleButton = () => {
    const theme = useTheme();
    const colorMode = useColorMode();
    
    return (
      <Paper elevation={3} sx={{ backgroundColor: theme.palette.background.default, display: 'flex', alignItems: 'center', padding: '8px', borderRadius: '0' }}>
        {theme.palette.mode === 'dark' ? <Brightness7 /> : <Brightness4 />}
        <Switch
          checked={theme.palette.mode === 'dark'}
          onChange={colorMode.toggleColorMode}
          inputProps={{ 'aria-label': 'dark mode toggle' }}
          sx={{ width: '48px' }} // Adjust the width as needed
        />
      </Paper>
    );
  };
  

export default ThemeToggle;
