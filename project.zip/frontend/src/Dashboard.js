import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { Box, Button, Typography, Grid, TextField, Paper, List, ListItem, ListItemText, Drawer } from '@mui/material';
import { CloudUpload, Refresh, ContentCopy } from '@mui/icons-material';
import { useTheme } from '@mui/material/styles';
import { useContext } from 'react';
import { AuthContext } from './AuthContext';

const Dashboard = () => {
  const theme = useTheme();
  const backgroundColor = theme.palette.mode === 'dark' ? '#1e1e1e' : '#f4f6f8';
  const [files, setFiles] = useState([]);
  const [uploadResults, setUploadResults] = useState([]);
  const [uploadMessage, setUploadMessage] = useState('');
  const [documents, setDocuments] = useState([]);
  const [analysis, setAnalysis] = useState('');
  const { user } = useContext(AuthContext);

  const handleFileChange = (event) => {
    setFiles(event.target.files);
    setUploadMessage(''); // Clear previous upload message
  };

  const handleUpload = async () => {
    const formData = new FormData();
    for (let i = 0; i < files.length; i++) {
      formData.append('files', files[i]);
    }

    try {
      const response = await axios.post('http://localhost:5001/api/uploads/upload', formData, {
        headers: {
          'Content-Type': 'multipart/form-data',
          'Authorization': `Bearer ${localStorage.getItem('auth-token')}`, // Ensure the token is sent
        },
      });
      setUploadResults(response.data.results);
      setAnalysis(response.data.analysis);
      setUploadMessage('Files uploaded successfully!');
      fetchDocuments(); // Fetch documents after upload
    } catch (error) {
      console.error('Error uploading files:', error);
      setUploadMessage('Error uploading files.');
    }
  };

  const fetchDocuments = async () => {
    try {
      const response = await axios.get('http://localhost:5001/api/users/documents', {
        headers: {
          'Authorization': `Bearer ${localStorage.getItem('auth-token')}`, // Ensure the token is sent
        },
      });
      setDocuments(response.data);
    } catch (error) {
      console.error('Error fetching documents:', error);
    }
  };

  useEffect(() => {
    if (user) {
      fetchDocuments();
    }
  }, [user]);

  return (
    <Box sx={{ display: 'flex', minHeight: '100vh' }}>
      <Drawer
        variant="permanent"
        sx={{
          width: 240,
          flexShrink: 0,
          [`& .MuiDrawer-paper`]: { width: 240, boxSizing: 'border-box' },
        }}
      >
        <Box sx={{ overflow: 'auto' }}>
          <Typography variant="h6" sx={{ padding: '20px' }}>Your Documents</Typography>
          {documents.map((category, index) => (
            <div key={index}>
              <Typography variant="subtitle1" sx={{ paddingLeft: '20px' }}>{category.category}</Typography>
              <List>
                {category.files.map((file, fileIndex) => (
                  <ListItem key={fileIndex}>
                    <ListItemText primary={file.filename} />
                  </ListItem>
                ))}
              </List>
            </div>
          ))}
        </Box>
      </Drawer>
      <Box sx={{ flexGrow: 1, padding: '20px', backgroundColor: backgroundColor }}>
        <Typography variant="h4" align="center" gutterBottom>
          Fal's Job Application Dashboard
        </Typography>
        <Paper elevation={3} sx={{ padding: '20px', borderRadius: '16px', marginBottom: '20px' }}>
          <Box sx={{ border: '2px dashed gray', padding: '20px', textAlign: 'center', borderRadius: '16px' }}>
            <CloudUpload fontSize="large" color="primary" />
            <Typography variant="h6">Upload Resume & Other Documents</Typography>
            <input
              type="file"
              multiple
              onChange={handleFileChange}
              style={{ display: 'none' }}
              id="file-upload-input"
            />
            <label htmlFor="file-upload-input">
              <Button variant="contained" sx={{ marginTop: '10px' }} component="span">
                Upload
              </Button>
            </label>
            {files.length > 0 && (
              <Box mt={2}>
                <Typography variant="body1">Selected files:</Typography>
                <List>
                  {Array.from(files).map((file, index) => (
                    <ListItem key={index}>
                      <ListItemText primary={file.name} />
                    </ListItem>
                  ))}
                </List>
              </Box>
            )}
            <Button variant="contained" sx={{ marginTop: '10px' }} onClick={handleUpload}>
              Submit
            </Button>
          </Box>
          {uploadMessage && (
            <Typography variant="body1" color="error" mt={2}>
              {uploadMessage}
            </Typography>
          )}
          {uploadResults.length > 0 && (
            <Box mt={2}>
              <Typography variant="h6">Upload Results:</Typography>
              {uploadResults.map((result, index) => (
                <Box key={index} mt={1}>
                  <Typography variant="subtitle1">{result.filename}</Typography>
                  <Typography variant="body2">{result.text}</Typography>
                </Box>
              ))}
            </Box>
          )}
        </Paper>
        <Paper elevation={3} sx={{ padding: '20px', borderRadius: '16px', marginBottom: '20px' }}>
          <Typography variant="h6">Profile Analysis and Job Recommendations</Typography>
          {analysis && (
            <Box mt={2}>
              <Typography variant="body1">{analysis}</Typography>
              <Button variant="contained" sx={{ marginTop: '10px' }}>Proceed with Search</Button>
              <Button variant="contained" sx={{ marginTop: '10px', marginLeft: '10px' }}>Refine Recommendation</Button>
            </Box>
          )}
        </Paper>
        <Grid container spacing={2}>
          <Grid item xs={12} md={6}>
            <Paper elevation={3} sx={{ padding: '20px', borderRadius: '16px' }}>
              <Typography variant="h6">Job Postings</Typography>
              {/* Add Job postings list */}
            </Paper>
          </Grid>
          <Grid item xs={12} md={6}>
            <Paper elevation={3} sx={{ padding: '20px', borderRadius: '16px' }}>
              <Typography variant="h6">Cover Letter</Typography>
              <TextField label="Cover Letter Instructions" variant="outlined" fullWidth sx={{ marginTop: '10px' }} />
              <Box sx={{ display: 'flex', justifyContent: 'space-between', marginTop: '10px' }}>
                <Button startIcon={<Refresh />} variant="outlined">Refresh</Button>
                <Button startIcon={<ContentCopy />} variant="outlined">Copy</Button>
              </Box>
              {/* Add Cover Letter Text */}
            </Paper>
          </Grid>
        </Grid>
        <Box sx={{ marginTop: '20px' }}>
          <Paper elevation={3} sx={{ padding: '20px', borderRadius: '16px' }}>
            <Typography variant="h6">Ask Application-Related Questions</Typography>
            <TextField label="Type your question" variant="outlined" fullWidth sx={{ marginTop: '10px' }} />
            {/* Add Answer display */}
          </Paper>
        </Box>
      </Box>
    </Box>
  );
};

export default Dashboard;
